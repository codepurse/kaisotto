# TODO v12

## Code

- Remove the deprecated `callback_set` option

## Test

- Test native `img`, native `iframe`, alone or in conjunction with `video`s.

Test more modules

* [ ] autoinitialize
* [ ] purge
* [ ] reveal
Thank you for taking the time to contribute!

To report a bug or request an enhancement or a feature, use the [issues page](https://github.com/verlok/lazyload/issues) on github

If you want to contribute actively with your own code, please:
- fork the repo on your namespace
- open a new branch
- develop your contribution on the branch
- create a pull request towards this repo

I recommend to do **one pull request per feature** to make sure your contribution is easy to review and accept.

Thank you and... may the force be with you!
